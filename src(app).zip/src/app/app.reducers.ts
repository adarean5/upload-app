import { ActionReducerMap } from '@ngrx/store';

export interface AppState {}

export const appReducers: ActionReducerMap<AppState> = {};
