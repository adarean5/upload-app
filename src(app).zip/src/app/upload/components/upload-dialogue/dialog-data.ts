export interface DialogData {
  file: File;
}
